#!/bin/sh

make -C demos/test_triangulate generic_test_triangulate
