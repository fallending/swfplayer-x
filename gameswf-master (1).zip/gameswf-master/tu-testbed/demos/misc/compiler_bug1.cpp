#include <string>

typedef std::string tu_string;

class tu_string;
