# SWFShapeDraw
[Matrix.createGradientBox(width:Number, height:Number, rotation:Number = 0, tx:Number = 0, ty:Number = 0):void] (http://docs.bonsaijs.org/matrix.js.html "Matrix#createGradientBox method implementation")

[flash.geom.Matrix] (http://help.adobe.com/en_US/FlashPlatform/reference/actionscript/3/flash/geom/Matrix.html "ActionScript® 3.0 Reference for the Adobe® Flash® Platform")
